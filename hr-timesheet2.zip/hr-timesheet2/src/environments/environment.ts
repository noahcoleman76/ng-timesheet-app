export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCHSoPm1LQYIy9EJ0c70XyHWzkdDC4fWRU",
    authDomain: "hr-timesheet-28f53.firebaseapp.com",
    projectId: "hr-timesheet-28f53",
    storageBucket: "hr-timesheet-28f53.appspot.com",
    messagingSenderId: "53475296743",
    appId: "1:53475296743:web:5a5d193327d824f1686942",
    measurementId: "G-1NEWT8R5SX"
  },
};